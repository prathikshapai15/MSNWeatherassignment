package com.msn.weather;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.internal.Configuration;

import com.google.common.base.Function;



/*import Training.Project.Configuration;*/

public class ReusableActionsClass {
	
	@FindBy(xpath ="//a[@data-id='3']") WebElement HeaderDropdown;
	@FindBy(xpath ="[contains(text(),'Travel')]']") WebElement Travel;
	@FindBy(xpath ="//a[@class='vertical']") WebElement Navigator;
	@FindBy(xpath = "//a[@class='place-selector__cover text-ellipsis js-autocomplete-place-cover']") WebElement FlightOrigin;
	@FindBy(xpath = "//a[@class='place-selector__cover text-ellipsis js-autocomplete-place-cover populated']") WebElement FlightDestination;
	@FindBy(xpath = " //div[@class='day']") WebElement Calenderpicker;
	@FindBy(xpath = "//*[@id=\"date-depart_table\"]/tbody/tr[3]/td[6]/div") WebElement DepartureDate;
	@FindBy(xpath = "//span[@class='ss-icon ss-icon-plus']") WebElement AddSymbol;
	@FindBy(xpath = "//*[@id='date-return_table']/tbody/tr[4]/td[4]/div") WebElement ReturnDate;
	
	public WebDriver driver;
	
	public void DriverSetup()
	{
		String path = System.getProperty("user.dir");
		System.out.println("System path is"+path );
		System.setProperty("webdriver.chrome.driver", path+"\\Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		WebDriverWait wait = new WebDriverWait(driver, 30);
		driver.manage().window().maximize();
		//Deleting all the cookies
		driver.manage().deleteAllCookies();
		//Specifying pageLoadTimeout and Implicit wait
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	

	/*public static void main(String[] args) {*/
		// TODO Auto-generated method stub
		/*public WebDriver driver = Configuration.browser(); // This will read the
		// configuration.java >
*/		// Gets the webdriver
		// instance
	
	public static void scroll() throws Exception
    {
	
	for (int n=0;;n++)
         {
            if(n>=3)
            {
            	break;
            }
                ((RemoteWebDriver) TestScenarios.driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
                Thread.sleep(2000);	
         }
    }


public void getWindowHandle() {
Set<String> handles = driver.getWindowHandles();// We will use this if
		// windows is greater
		// than 1 - otherwise we
		// just getwindowhandle
		// ();
if (handles.size() >= 1) {
System.out.println("Number of broiwsers opened are"
+ handles.size());
for (String handle : handles) {
driver.switchTo().window(handle);

}
}

}

public void ExplicitWait(WebElement element) {

	WebDriverWait wait = new WebDriverWait(driver, 30);

	wait.until(ExpectedConditions.visibilityOf(element));

}

public WebElement fluentWait(final By locator) {
Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
.withTimeout(30, TimeUnit.SECONDS)
.pollingEvery(5, TimeUnit.SECONDS)
.ignoring(NoSuchElementException.class);

WebElement foo = wait.until(new Function<WebDriver, WebElement>() {
public WebElement apply(WebDriver driver) {
return driver.findElement(locator);
}
});
return foo;
};

public static WebElement explicitWait(WebDriver driver, By by) {
Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
.withTimeout(20, TimeUnit.SECONDS)
.pollingEvery(2, TimeUnit.SECONDS)
.ignoring(NoSuchElementException.class);

WebElement element = wait.until(new Function<WebDriver, WebElement>() {
public WebElement apply(WebDriver driver) {
return driver.findElement(By.id("foo"));
}
});
return element;
}

public void enterdata(WebElement e,String data){

e.sendKeys(data);
}

public static void window(WebElement ele) throws Exception
{

	Actions actionOpenLinkInNewTab = new Actions(TestScenarios.driver);
	actionOpenLinkInNewTab.moveToElement(ele)
	.keyDown(Keys.COMMAND)
	.keyDown(Keys.SHIFT)
	.click(ele)
	.keyUp(Keys.COMMAND)
	.keyUp(Keys.SHIFT)
	.perform();
	Thread.sleep(3000);		

}

	}


