package com.msn.weather;

import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;



@Test(priority=1)
public class TestScenarios extends ReusableActionsClass {
		
/*======================== Test scenario 1 [Handling drop-downs & Travel tickets booking ] ==================================*/
	public static WebDriver driver;	
	
	{
		
		DriverSetup(); //Defined paths of driver in ReusableActionsClass

		driver.get("https://www.msn.com/en-in/weather/today/New-Delhi.Delhi.India/we-city-28.608.77.201?iso=IN");
		System.out.println("Opened MSN");
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		ExplicitWait(HeaderDropdown);
		HeaderDropdown.click();
        ExplicitWait(Travel);
		System.out.println("Clicked on expandable link");
		Travel.click();
		System.out.println("Clicked on Travel link");
		
        /* ========Encountering issues while navigating to travel pages WHOOPS ERROR*/
		ExplicitWait(Navigator);
		Navigator.click();
		System.out.println("Clicked on Travel link at header");
		System.out.println("Checking for TRAVEL SITE");

		driver.get("https://www.msn.com/en-in/travel");
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		
	   /*Cant proceed with further flow due to Page not found WHOOPS error navigate back*/
		driver.navigate().back();
		System.out.println("Driver navigated back");
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.get("https://flights.msn.com/en-in/flight-search");
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	
		Actions action = new Actions(driver);
		ExplicitWait(FlightOrigin);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", FlightOrigin);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		action.moveToElement(FlightOrigin).sendKeys("New Delhi");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		
		ExplicitWait(FlightDestination);
		Actions action1 = new Actions(driver);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		JavascriptExecutor executor1 = (JavascriptExecutor)driver;
		executor1.executeScript("arguments[0].click();", FlightDestination);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		action1.moveToElement(FlightDestination).sendKeys("Chennai");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		ExplicitWait(Calenderpicker);
		Calenderpicker.click();
		ExplicitWait(DepartureDate);
		DepartureDate.click();
		ExplicitWait(AddSymbol);
		AddSymbol.click();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		ExplicitWait(ReturnDate);
		ReturnDate.click();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//i[@class='pax-icon ss-icon ss-icon-child']")).click();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//div[@class='dropdown-items js-dropdown-container-wrapper active']//a[@class='dropdown-item js-dropdown-item js-control-item'][contains(text(),'1')]")).click();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//span[@class='ss-icon ss-icon-search']")).click();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		
		/*======================== Test scenario 2 ==================================*/
		/*Handling window()*/
		driver.get("https://www.msn.com/en-in/weather/today/New-Delhi.Delhi.India/we-city-28.608.77.201?iso=IN");
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		try {
			ReusableActionsClass.scroll();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"u_0_0\"]/div/button/span")).click();
		System.out.println("============== Clicked on Like face book option at footer navigating to child window============");
		Set<String> h=TestScenarios.driver.getWindowHandles();
		System.out.println("No of handles is:"+h.size());
		System.out.println("**** Handles are ****");
		String handle[]=new String[h.size()];
		int i=0;
		for(String s:h)
		{
			System.out.println(s);
			handle[i]=s;
			i++;
		}
		driver.switchTo().window(handle[1]);
		driver.close();
		System.out.println("Driver closing & switching to parent");
		driver.switchTo().window(handle[0]);
		driver.findElement(By.xpath("//*[@id=\"follow-button\"]/i")).click();
		System.out.println("============== Clicked on Follow option of twiter at footer navigating ============");
		driver.quit();
	}
	

}

